/*
var ractive, courseData;

$.getJSON('/courses/courses.json', function(data) {
	courseData = data;


	initRactive();
});


function initRactive() {
	ractive = new Ractive({
	  el: 'courseOverview',
	  template: '#course',
	  noIntro: true, // disable transitions during initial render
	  data: {
	    courseData: courseData
	  }
	});

	ractive.on()
}
*/